#ifndef ANNONCES_H
#define ANNONCES_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>


class annonces
{
private:
    int identifiant,billet,prix;
    QString date,sejour;
public:
    annonces();
    annonces(int,int,int,QString,QString);
    int get_billet();
    int get_identifiant();
    int get_prix();
    QString get_date();
    QString get_sejour();
    bool ajouter();
    bool modifier(int);
    QSqlQueryModel * afficher();
    bool supprimer(int);
};

#endif // ANNONCES_H
