#ifndef BILLETS_H
#define BILLETS_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>


class billets
{
private:
    int identifiant,vol;
    int bateau;
public:
    billets();
    billets(int,int,int);
    int get_bateau();
    int get_identifiant();
    int get_vol();
    bool ajouter();
    bool modifier(int);
    QSqlQueryModel * afficher();
    bool supprimer(int);
};

#endif // BILLETS_H
