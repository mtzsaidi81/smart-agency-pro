#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "billets.h"
#include "annonces.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_AjoutBillet_clicked();

    void on_ModifBillet_clicked();

    void on_SuppBillet_clicked();

    void on_AjoutAnnonce_clicked();

    void on_ModifAnnonce_clicked();

    void on_SuppAnnonce_clicked();

private:
    Ui::MainWindow *ui;
    billets tmpbillets;
    annonces tmpannonces;
};
#endif // MAINWINDOW_H
